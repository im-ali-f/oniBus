from django.apps import AppConfig


class OnibusappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oniBusApp'
